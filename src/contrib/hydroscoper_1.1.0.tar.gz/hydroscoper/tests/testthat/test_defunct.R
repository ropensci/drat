context("defunct related tests")

test_that("get_coords returns an error", {
  expect_error(get_coords())
})
