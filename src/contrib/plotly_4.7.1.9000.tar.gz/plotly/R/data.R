#' Wind data
#'
#' Description TBD.
#'
#' @format A data frame with three variables: `r`, `t`,
#'   `nms`.
"wind"

#' Mic data
#'
#' Description TBD.
#'
#' @format A data frame with three variables: `r`, `t`,
#'   `nms`.
"mic"

#' Hobbs data
#'
#' Description TBD.
#'
#' @format A data frame with three variables: `r`, `t`,
#'   `nms`.
"hobbs"
