library(testthat)
library(rgeospatialquality)

test_check("rgeospatialquality")

