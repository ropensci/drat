rgeospatialquality
==================

__THIS PACKAGE IS DEPRECATED - IT NO LONGER WORKS__
