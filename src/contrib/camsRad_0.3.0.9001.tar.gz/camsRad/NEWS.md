# camsRad 0.3.0 (2016-11-07)
=========================
* Compliance with rOpenSci review
### MINOR IMPROVEMENTS
* covr::codecov() badge included
* more testing
* removed dependency to readr package
* return data.frame instead of tibble
* new authentication method
* more examples and improved documentation
* cams_api stops if error in httr calls or errir in returned content

# camsRad 0.2.0 (2016-08-22)
=========================
* Realese for onboarding to rOpenSci
### MINOR IMPROVEMENTS
* Exported functions are documented with examples
* README extended with examples
* vignette added
* Travis-CI added
* Test with testhat added


# camsRad 0.1.0 (2016-08-18)
=========================
* Initial public release
