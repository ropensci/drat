library(testthat)
library(camsRad)

test_check("camsRad")
