#' This function is defunct.
#' @export
#' @rdname ld_search-defunct
#' @keywords internal
ld_search <- function(...) {
  .Defunct(msg = "This function is defunct; SNAP has been taken down.
  See <https://www.broadinstitute.org/snap/snap>")
}
