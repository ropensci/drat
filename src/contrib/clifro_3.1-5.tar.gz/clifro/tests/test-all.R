library(testthat)
library(clifro)

test_check("clifro")
