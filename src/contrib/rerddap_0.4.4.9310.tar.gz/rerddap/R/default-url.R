#' Default ERDDAP server URL
#' 
#' @details default url is https://upwell.pfeg.noaa.gov/erddap
#'
#' @export
eurl <- function() "https://upwell.pfeg.noaa.gov/erddap/"
