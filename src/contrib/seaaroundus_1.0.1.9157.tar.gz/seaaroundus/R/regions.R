#' Regions details
#'
#' @name regions
#' @details Region options
#' \itemize{
#'  \item eez
#'  \item lme
#'  \item rfmo
#'  \item highseas
#'  \item fao
#'  \item eez-bordering
#'  \item fishing-entity
#'  \item taxon
#'  \item global
#' }
NULL
