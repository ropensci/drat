# Description	Unlock already submitted deposition for editing.
# URL	https://zenodo.org/api/deposit/depositions/:id/actions/edit
# Method	POST
# Request headers	None
# Scopes	deposit:actions
# URL parameters	
# Required:
# id: Deposition identifier
# Success response	
# Code: 201 Created
# Body: a deposition resource.