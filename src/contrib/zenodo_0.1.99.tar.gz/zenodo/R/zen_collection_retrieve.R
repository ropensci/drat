# Description	Retrieve a single deposition resource.
# URL	https://zenodo.org/api/deposit/depositions/:id
# Method	GET
# URL parameters	
# Required:
# id: Deposition identifier
# Success response	
# Code: 200 OK
# Body: a deposition resource.