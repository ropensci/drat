


zen_auth <- function(key = "", secret = "") {
  # Once completed, this fn will allow for
  # automatic authentication.
  # For now, it's just as easy to add a token
  # to one's R profile to use the remaining endpoints
}
