library(testthat)
library(zenodo)

test_check("zenodo")
