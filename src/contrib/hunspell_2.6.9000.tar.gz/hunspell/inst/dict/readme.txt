Aug 2017: updated en_US from https://cgit.freedesktop.org/libreoffice/dictionaries/tree/en
