library(testthat)
library(assertr)

test_check("assertr")
