library(testthat)
library(osmplotr)

test_check("osmplotr")
