The geojson schema here is taken from the [SchemaStore](https://github.com/SchemaStore/schemastore) repository. It is distributed under the Apache 2.0 license (see LICENSE.md)
