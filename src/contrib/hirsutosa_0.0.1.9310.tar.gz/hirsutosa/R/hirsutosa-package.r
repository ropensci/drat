#' hirsutosa
#' 
#' @importFrom crul HttpClient
#' @importFrom jsonlite fromJSON toJSON
#' @docType package
#' @aliases hirsutosa-package
#' @author Scott Chamberlain \email{myrmecocystus+r@@gmail.com}
#' @name hirsutosa
NULL
