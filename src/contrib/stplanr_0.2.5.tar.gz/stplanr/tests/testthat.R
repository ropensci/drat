library(testthat)
library(stplanr)

test_check("stplanr")
