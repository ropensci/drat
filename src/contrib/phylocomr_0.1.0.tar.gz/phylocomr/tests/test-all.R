library("testthat")
test_check("phylocomr")
