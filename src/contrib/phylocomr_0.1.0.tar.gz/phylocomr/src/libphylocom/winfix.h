#ifdef _WIN32
#define random rand
#define srandom srand
#endif
