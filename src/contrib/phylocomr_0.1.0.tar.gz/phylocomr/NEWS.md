phylocomr 0.1.0
===============

### NEW FEATURES

* released to CRAN
