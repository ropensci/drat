#' util_facetplot() for visual overview
#'
#' @description Plot multiple raster (RasterStack, -brick or list of raster) side by side as facets.
#'
#' @details The output uses ggplots faceting and beforehand raster2tibble.
#' Thus you will loose any spatial information (resolution, extent or reference system).
#' Only raw tiles are displayed and the number of cells determines the size of the plot.
#' This can lead to huge size differences between maps, but if you plot for example
#' multiple maps from a time series side by side it works as intended. Depending on the
#' size of the maps it is advisable to store the plot in an object and print it to
#' a file. This will help with compressing and rendering the image.
#'
#' @param mpdta Raster* Layer, Stack, Brick or a list of rasterLayers.
#' @param nrow,ncol Number of rows and columns.
#'
#' @return ggplot
#'
#' @examples
#' \dontrun{
#' l1 <- NLMR::nlm_fbm(64, 64)
#' l2 <- NLMR::nlm_planargradient(64, 64)
#' l3 <- NLMR::nlm_randomrectangularcluster(ncol = 60, nrow = 60, minl = 5, maxl = 10)
#' l4 <- NLMR::nlm_random(64, 64)
#'
#' bri1 <- raster::brick(l1, l2)
#' names(bri1) <- c("FBM", "GRADIENT")
#' util_facetplot(bri1)
#'
#' lst1 <- list(layer1 = l1,
#'              layer2 = l2,
#'              layer3 = l3,
#'              layer4 = l4)
#' util_facetplot(lst1)
#' }
#'
#' @aliases util_facetplot
#' @rdname util_facetplot
#'
#' @export
#'

util_facetplot <- function(mpdta, nrow = NULL, ncol = NULL) {

  if (checkmate::testClass(mpdta, "RasterLayer") ||
      checkmate::testClass(mpdta, "RasterStack") ||
      checkmate::testClass(mpdta, "RasterBrick")) {

    maplist <- list()
    for (i in seq_len(raster::nlayers(mpdta))) {
      maplist <- append(maplist, list(raster::raster(mpdta, layer = i)))
    }
    mpdta <- magrittr::set_names(maplist, names(mpdta))
  }

  maptibb <- tibble::enframe(mpdta, "id", "maps") %>%
             dplyr::mutate(maps = purrr::map(.$maps, util_raster2tibble)) %>%
             tidyr::unnest()
  # %>%
  #            dplyr::mutate(id = factor(id, levels = names(mpdta)))

  p <- ggplot2::ggplot(maptibb, ggplot2::aes_string("x", "y")) +
        ggplot2::coord_fixed() +
        ggplot2::geom_raster(ggplot2::aes_string(fill = "z")) +
        ggplot2::facet_wrap(~id, nrow = nrow, ncol = ncol) +
        ggplot2::scale_x_continuous(expand = c(0, 0), limits = c(0,max(maptibb$x))) +
        ggplot2::scale_y_continuous(expand = c(0, 0), limits = c(0,max(maptibb$y))) +
        ggplot2::guides(fill = FALSE) +
        ggplot2::labs(titel = NULL, x = NULL, y = NULL) +
        theme_facetplot()

  return(p)
}
