#' landscapetools
#'
#' \emph{landscapetools} provides utility functions to work with landscape data
#' (raster* Objects).
#'

# nocov start
# nolint start
"_PACKAGE"

globalVariables(c("value", "."))

# nolint end
# nocov end
