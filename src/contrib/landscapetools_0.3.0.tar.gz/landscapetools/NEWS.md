# landscapetools 0.3.0

* landscapetools will be a safe haven for the remnants (utility functions) of NLMR
