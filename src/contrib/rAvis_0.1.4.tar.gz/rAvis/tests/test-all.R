# Temporarily disabled:
# The tests dependent on the API have been moved to
# tests/apitest. All other tests regarding the package will be enabled once
# a strategy for mocking the API client on testing environment is on place.
#
# Still you can run manually the test with test_dir in the meantime

#library(testthat)
#test_check("rAvis")
