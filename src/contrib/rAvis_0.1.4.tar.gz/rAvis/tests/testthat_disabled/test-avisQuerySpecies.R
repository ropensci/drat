context ("avisQuerySpecies")

test_that("avisQuerySpecies finds existing especies",{ 
	# TODO. tests based on mocked API
})

test_that("avisQuerySpecies does not find unexisting especies",{ 
	# TODO. tests based on mocked API
})
