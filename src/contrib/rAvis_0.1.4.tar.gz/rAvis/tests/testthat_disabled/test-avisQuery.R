context ("avisQuery")

# TODO: preload mock for .avisApiBusAvanzada

test_that("test avisQuery has the correct structure",{ 

    # TODO: test that lat lon columns are added
})

# TODO: test finds existing expecies / not finds unexistent especies
