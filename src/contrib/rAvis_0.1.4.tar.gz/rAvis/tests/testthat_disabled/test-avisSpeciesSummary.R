# test for avisSpeciesSummary in rAvis

context ("avisSpeciesSummary")

# TODO: add tests based on .avisApiBusEspecie
