context ("avisMapSpecies")

test_that("avisMapSpecies ",{ 
	
  	expect_error(avisMapSpecies ("Pica pic"), )  
})
