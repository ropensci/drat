library(testthat)
test_check("taxizedb")