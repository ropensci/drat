library(testthat)
library(FedData)

test_check("FedData")
