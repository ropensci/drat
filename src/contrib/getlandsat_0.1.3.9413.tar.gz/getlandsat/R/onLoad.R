.onLoad <- function(libname, pkgname) {
  Sys.setenv(AWS_DEFAULT_REGION = "us-west-2")
}
