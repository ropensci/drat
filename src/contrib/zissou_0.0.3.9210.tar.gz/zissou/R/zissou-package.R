#' zissou
#'
#' @import xml2
#' @importFrom crul HttpClient
#' @name zissou-package
#' @aliases zissou
#' @docType package
#' @keywords package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#'
#' @examples
#' print("hello")
NULL
