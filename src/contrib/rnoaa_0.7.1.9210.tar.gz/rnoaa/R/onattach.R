.onAttach = function(libname,pkgname) {
  options(geonamesUsername = "schamber789")
  options(geonamesHost = "api.geonames.org")
}
