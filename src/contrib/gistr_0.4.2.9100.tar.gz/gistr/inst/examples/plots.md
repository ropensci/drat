

## Scatter plot 


```r
plot(mpg ~ cyl, data=mtcars)
```

![plot of chunk unnamed-chunk-2](https://i.imgur.com/UVoPCi3.png)

## Bar plot


```r
barplot(VADeaths)
```

![plot of chunk unnamed-chunk-3](https://i.imgur.com/13Re4qX.png)

## Histogram


```r
hist(iris$Petal.Length)
```

![plot of chunk unnamed-chunk-4](https://i.imgur.com/EItnHcZ.png)
