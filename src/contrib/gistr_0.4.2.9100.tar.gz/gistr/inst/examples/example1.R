#' ---
#' output: md_document
#' ---

#' I shall generate random numbers.
x <- rnorm(1000)

#' And I shall summarize them.
summary(x)
