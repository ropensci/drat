I shall generate random numbers.

    x <- rnorm(1000)

And I shall summarize them.

    summary(x)

    ##     Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
    ## -2.83791 -0.65021  0.06139  0.01810  0.67508  3.02495
