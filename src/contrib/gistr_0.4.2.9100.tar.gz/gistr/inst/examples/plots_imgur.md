

## Scatter plot 


```r
plot(mpg ~ cyl, data=mtcars)
```

![plot of chunk unnamed-chunk-2](https://i.imgur.com/giiuYcd.png)

## Bar plot


```r
barplot(VADeaths)
```

![plot of chunk unnamed-chunk-3](https://i.imgur.com/jL7cJJb.png)

## Histogram


```r
hist(iris$Petal.Length)
```

![plot of chunk unnamed-chunk-4](https://i.imgur.com/OcymFMa.png)
