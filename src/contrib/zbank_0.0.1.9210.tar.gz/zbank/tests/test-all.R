library("testthat")
test_check("zbank")
