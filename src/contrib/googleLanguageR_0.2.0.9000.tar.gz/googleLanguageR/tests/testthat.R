library(httptest)
library(googleLanguageR)

test_check("googleLanguageR")
