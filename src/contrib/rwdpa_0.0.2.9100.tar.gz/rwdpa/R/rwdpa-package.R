#' World Database of Protected Areas
#'
#' @import httr sp rgdal rmapshaper readr dplyr
#' @importFrom jsonlite fromJSON
#' @name rwdpa-package
#' @aliases rwdpa
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
