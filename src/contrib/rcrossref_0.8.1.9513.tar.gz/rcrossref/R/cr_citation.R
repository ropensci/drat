#' This function is defunct
#'
#' @export
#' @rdname cr_citation-defunct
#' @keywords internal
cr_citation <- function(...) {
  .Defunct(new = "cr_cn", package = "rcrossref", msg = "Removed - see cr_cn()")
}
