library("testthat")
test_check("pleiades")
