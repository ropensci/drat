#' \strong{pleiades}
#'
#' @name pleiades
#' @name pleiades-package
#' @aliases pleiades
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @docType package
NULL
