pleiades 0.2.0
==============

## MINOR IMPROVEMENTS

* due to `dplyr` changes, now requiring `dbplyr` and `DBI`
in this package (#8)
* make sure curl options via `...` are passed on to HTTP request
in `pl_status()`



pleiades 0.1.0
==============

### NEW FEATURES

* Released to CRAN.
