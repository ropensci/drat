library(testthat)
library(epubr)

test_check("epubr")
