library(testthat)
library(EML)

test_check("EML")
