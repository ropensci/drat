
## Run this to have list available without having to re-parse EML every time
## FIXME consider sysdata for this?


standardUnits <- get_unitList()

