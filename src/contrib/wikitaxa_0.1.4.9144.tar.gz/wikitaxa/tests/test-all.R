library(testthat)
library(wikitaxa)
test_check("wikitaxa")
