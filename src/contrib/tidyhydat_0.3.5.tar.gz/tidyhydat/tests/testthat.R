library(testthat)
library(tidyhydat)
library(dplyr)
library(lubridate)

test_check("tidyhydat")
