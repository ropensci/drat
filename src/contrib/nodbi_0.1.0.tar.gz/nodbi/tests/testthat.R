library(testthat)
test_check("nodbi")
