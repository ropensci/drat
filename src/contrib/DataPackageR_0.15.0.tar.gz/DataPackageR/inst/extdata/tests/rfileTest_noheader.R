data <- runif(100)
