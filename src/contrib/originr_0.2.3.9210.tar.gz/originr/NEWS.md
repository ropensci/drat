originr 0.2.0
=============

### NEW FEATURES

* Added a new data source: Global Register of Introduced and Invasive
Species (GRIIS). See `griis()` (#5) (#7)

### BUG FIXES

* Fix to `flora_europaea()` to convert factors to character and 
to stop with meaningful message when more than one species 
passed in (#8)


originr 0.1.0
=============

### NEW FEATURES

* Released to CRAN.
