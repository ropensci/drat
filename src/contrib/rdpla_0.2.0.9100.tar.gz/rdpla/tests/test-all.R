library("testthat")
library("rdpla")

test_check("rdpla")
