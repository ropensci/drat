rdpla 0.2.0
===========

### NEW FEATURES

* Now using `crul` package for HTTP requests (#22)
* Gains new functions `dpla_bulk()` and `dpla_bulk_list()`, the former
of which downloads the DPLA bulk compressed JSON files, and the latter
of which lists the possible data to download. Latter is used internally 
in the former. (#18)

### BUG FIXES

* fixed bug in `dpla_items` (#23)


rdpla 0.1.0
===========

### NEW FEATURES

* Released to CRAN
