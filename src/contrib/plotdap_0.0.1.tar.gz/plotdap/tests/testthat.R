library("testthat")
library("plotdap")

test_check("plotdap")
