#' R client for Citation Style Language (CSL) styles
#'
#' @name seasl-package
#' @aliases seasl
#' @docType package
#' @title R client for CSL styles
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
