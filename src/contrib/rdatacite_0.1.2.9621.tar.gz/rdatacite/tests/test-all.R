library("testthat")
test_check("rdatacite")
