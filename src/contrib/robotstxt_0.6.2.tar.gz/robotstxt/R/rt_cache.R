#' get_robotstxt() cache
rt_cache <- new.env( parent = emptyenv() )

