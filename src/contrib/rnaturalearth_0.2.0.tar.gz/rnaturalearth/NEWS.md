rnaturalearth 0.2.0
===================

* add to river options in ne_download() by adding to data_list_physical.csv fixing [#23](https://github.com/ropensci/rnaturalearth/issues/23)
* update data to new version [Natural Earth v4.1](https://www.naturalearthdata.com/blog/miscellaneous/natural-earth-v4-1-0-release-notes/) released May 2018.


rnaturalearth 0.1.0  CRAN
=========================

* Initial release
* sf support