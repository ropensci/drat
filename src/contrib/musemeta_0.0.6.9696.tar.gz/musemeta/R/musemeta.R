#' R client for museum metadata
#'
#' @name musemeta-package
#' @aliases musemeta
#' @docType package
#' @title R client for museum metadata
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
