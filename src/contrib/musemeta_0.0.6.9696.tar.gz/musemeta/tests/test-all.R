library("testthat")
test_check("musemeta")
