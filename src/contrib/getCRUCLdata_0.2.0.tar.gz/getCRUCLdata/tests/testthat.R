library(testthat)
library(getCRUCLdata)

test_check("getCRUCLdata")
