fauxpas 0.2.0
=============

### NEW FEATURES

* xxxx 


fauxpas 0.1.0
=============

### NEW FEATURES

* Released to CRAN.
