### 0.1.8

#### BUG FIXES
* Fixes to documentation.

#### MINOR IMPROVEMENTS
* Documentation enhancements.


# bittrex 0.1.0

* First version of the package including:
    * Market summaries, price, order book, and volume for Bittrex crypto-currencies.
    * The ability to trade crypto-currencies with a user account.
