library('testthat')
library('bittrex')
test_check('bittrex')
