# cRegulome 0.99.0

    - cRegulome v0.99.0 (2017-09-06) Submit to rOpenSci


# cRegulome 0.1.0

    - cRegulome v0.1.0 (2018-02-08) Approved by rOpenSci
    - On CRAN
  
# cRegulome 0.1.1

    - fix installing in default library tree
