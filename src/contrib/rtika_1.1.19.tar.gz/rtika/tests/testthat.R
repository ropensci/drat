library(testthat)
library(rtika)

test_check("rtika")
