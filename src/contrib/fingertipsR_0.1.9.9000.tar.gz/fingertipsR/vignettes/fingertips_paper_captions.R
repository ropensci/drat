# fingertips_paper_captions.R

fig_caps <- captioner(prefix = "Figure")

fig_caps(name = "life_exp_birth", "Life expectancy at birth by Index of Multiple Deprivation score, Upper Tier Local Authority, England 2012-14")
