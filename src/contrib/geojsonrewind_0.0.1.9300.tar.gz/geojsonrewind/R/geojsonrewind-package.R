#' @title \strong{GeoJSON Rewinding}
#'
#' @description a package for fixing ring order, see also the
#' right-hand rule for geojson
#'
#' @name geojsonrewind-package
#' @aliases geojsonrewind
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @docType package
NULL
