library(testthat)
library(tif)

test_check("tif")
