library(testthat)
library(ssh)

#test_check("ssh")
