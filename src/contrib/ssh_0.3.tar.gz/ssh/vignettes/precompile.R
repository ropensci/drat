#Vignettes that depend on internet access have been precompiled:

library(knitr)
knit("vignettes/intro.Rmd.in.Rmd", "vignettes/intro.Rmd")
