library(testthat)
test_check("rnoaa")