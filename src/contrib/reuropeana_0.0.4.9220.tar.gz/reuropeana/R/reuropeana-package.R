#' R Client for Europeana.
#'
#' @name reuropeana-package
#' @aliases reuropeana
#' @docType package
#' @author Scott Chamberlain
NULL
