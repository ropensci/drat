library(testthat)
library(reuropeana)

test_check("reuropeana")
