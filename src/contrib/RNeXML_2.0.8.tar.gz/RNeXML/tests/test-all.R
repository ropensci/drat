library("testthat")
test_check("RNeXML")


