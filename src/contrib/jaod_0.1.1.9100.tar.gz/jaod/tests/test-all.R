library("testthat")
library("jaod")

test_check("jaod")
