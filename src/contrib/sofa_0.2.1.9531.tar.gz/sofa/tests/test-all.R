library("testthat")
library("sofa")
test_check("sofa")
