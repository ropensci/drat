library(testthat)
library(NLMR)

test_check("NLMR")
