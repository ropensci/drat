library(testthat)
library(nodbi)

test_check("nodbi")
