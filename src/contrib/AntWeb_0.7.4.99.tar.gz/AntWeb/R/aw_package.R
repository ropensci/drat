#' @title AntWeb
#' @name AntWeb
#' @docType package
#' @details \href{http://www.antweb.org/}{The AntWeb} world's largest online database of images, specimen records, and natural history information on ants. The database is maintained and hosted by the \href{http://www.calacademy.org/}{California Academy of Sciences}.
NULL