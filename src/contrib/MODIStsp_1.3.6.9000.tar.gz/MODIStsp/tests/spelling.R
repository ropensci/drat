spelling::spell_check_test(vignettes = TRUE, lang = "en_GB", error = FALSE)
