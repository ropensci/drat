Sys.setenv("R_TESTS" = "")
library(httptest)
test_check("MODIStsp")
