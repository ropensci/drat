library(testthat)
library(taxadb)

test_check("taxadb")
