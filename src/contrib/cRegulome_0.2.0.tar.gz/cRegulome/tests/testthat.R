library(testthat)
library(cRegulome)

test_check("cRegulome")
