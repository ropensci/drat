library('testthat')
test_check("spocc")
