library("testthat")
test_check("rorcid")
