library(testthat)
library(travis)

test_check("travis")
