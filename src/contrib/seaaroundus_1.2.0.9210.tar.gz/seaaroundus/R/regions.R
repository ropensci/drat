#' Regions details
#'
#' @name regions
#' @details Region options
#' - eez
#' - lme
#' - rfmo
#' - highseas
#' - fao
#' - eez-bordering
#' - fishing-entity
#' - taxa
#' - global
#' #'See \code{\link{listregions}} on how to obtain id numbers
NULL
