#' R client for Riak.
#'
#' @name reeack-package
#' @aliases reeack
#' @docType package
#' @title R client for Riak
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
