#' serialize a data.frame
#'
#' @export
#' @param df a data.frame, required
#' @param string a string, required
#' @return character string
#' @examples
#' riak_serialize(iris)
#' riak_unserialize(riak_serialize(iris))
#'
#' identical(
#'   iris,
#'   riak_unserialize(riak_serialize(iris))
#' )
riak_serialize <- function(df) {
  rawToChar(serialize(object = df, connection = NULL, ascii = TRUE))
}

#' unserialize a data.frame
#' @export
#' @name riak_serialize
riak_unserialize <- function(string) {
  unserialize(charToRaw(string))
}
