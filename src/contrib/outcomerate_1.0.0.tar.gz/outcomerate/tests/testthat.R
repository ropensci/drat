library(testthat)
library(outcomerate)

test_check("outcomerate")
