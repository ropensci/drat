.onAttach <- function(libname, pkgname) {
    packageStartupMessage("The Composite Gazetteer of Antarctica is made available under a CC-BY license.\nIf you use it, please cite it:\nComposite Gazetteer of Antarctica, Scientific Committee on Antarctic Research. GCMD Metadata (http://gcmd.nasa.gov/records/SCAR_Gazetteer.html)")
}
