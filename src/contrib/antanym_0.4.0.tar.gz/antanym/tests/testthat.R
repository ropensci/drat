library(testthat)
library(magrittr)
library(antanym)

test_check("antanym")
