library("testthat")
test_check("crminer")
