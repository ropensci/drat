library("testthat")
test_check("suppdata")
