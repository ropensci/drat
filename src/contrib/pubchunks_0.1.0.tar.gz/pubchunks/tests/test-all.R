library("testthat")
test_check("pubchunks")
