hathi
=======

[![Build Status](https://api.travis-ci.org/ropensci/hathi.png)](https://travis-ci.org/ropensci/hathi)

An R client for HathiTrust API.

## Installation

```r
install_github("ropensci/hathi")
library("hathi")
```

## Usage

```r
hathi_bib(oclc=424023)
```

## Meta

* Please [report any issues or bugs](https://github.com/ropensci/hathi/issues).
* License: MIT
* Get citation information for `hathi` in R doing `citation(package = 'hathi')`

[![ropensci](http://ropensci.org/public_images/github_footer.png)](http://ropensci.org)

[tut]: http://ropensci.org/tutorials/hathi.html
