library(testthat)
library(smapr)

test_check("smapr")
