#' SPARQL DSL Client
#'
#' @name sparqldsl-package
#' @aliases sparqldsl
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
