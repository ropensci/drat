#' USAboundariesData
#'
#' @name USAboundariesData
#' @docType package
NULL

if (getRversion() >= "2.15.1") {
  utils::globalVariables(c())
}
