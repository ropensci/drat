library(testthat)
library(arkdb)

test_check("arkdb")
