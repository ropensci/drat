#' Default ERDDAP server URL
#'
#' @export
eurl <- function() "https://upwell.pfeg.noaa.gov/erddap/"
