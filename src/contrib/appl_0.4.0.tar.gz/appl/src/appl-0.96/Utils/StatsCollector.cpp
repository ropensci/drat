#include "StatsCollector.h"

using namespace momdp;
namespace momdp 
{
long StatsCollector::memoryUsage = 0;

StatsCollector::StatsCollector(void)
{
}

StatsCollector::~StatsCollector(void)
{
}
}
