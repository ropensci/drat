#include "BeliefCacheSet.h"

BeliefCacheSet::BeliefCacheSet(void)
{
}

BeliefCacheSet::~BeliefCacheSet(void)
{
}
