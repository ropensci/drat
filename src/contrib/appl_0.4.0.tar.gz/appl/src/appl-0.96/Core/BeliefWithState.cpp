#include "BeliefWithState.h"

BeliefWithState::BeliefWithState(void) : sval(-1), bvec(new SparseVector())
{
}

BeliefWithState::~BeliefWithState(void)
{
}
