/** 
 * Part of the this code is derived from ZMDP: http://www.cs.cmu.edu/~trey/zmdp/
 * ZMDP is released under Apache License 2.0
 * The rest of the code is released under GPL v2 
 */


#ifndef FACMODELSTRUCTS_H
#define FACMODELSTRUCTS_H

#include "MathLib.h"
#include "BeliefWithState.h"
using namespace std;
using namespace momdp;

namespace momdp 
{


};
#endif // FACMODELSTRUCTS_H

/***************************************************************************
* REVISION HISTORY

 ***************************************************************************/

