/* All SARSOP source code can be found in appl-0.96 directory.
   R CMD check seems to be confused by use of subdirectories and
   warns that src is empty without this file here.

 */
