library(testthat)
library(appl)

test_check("appl")
