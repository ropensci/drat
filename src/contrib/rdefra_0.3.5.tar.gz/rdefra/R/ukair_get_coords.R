#' Get Easting and Northing coordinates from DEFRA
#'
#' @description This function takes as input the UK AIR ID and returns Easting
#' and Northing coordinates (British National Grid, EPSG:27700).
#'
#' @param ids contains the station identification code defined by DEFRA. It can
#' be: a) an alphanumeric string, b) a vector of strings or c) a data frame. In
#' the latter case, the column containing the codes should be named "UK.AIR.ID",
#' all the other columns will be ignored.
#'
#' @details If the input is a data frame with some of the columns named
#' "UK.AIR.ID", "Latitude" and "Longitude", the function only infills missing
#' Latitude/Longitude values.
#'
#' @return A data.frame containing at least five columns named "UK.AIR.ID",
#' "Easting", "Northing", "Latitude" and "Longitude".
#'
#' @export
#'
#' @examples
#'  \dontrun{
#'  # Case a: alphanumeric string
#'  ukair_get_coords("UKA12536")
#'
#'  # Case b: vector of strings
#'  ukair_get_coords(c("UKA15910", "UKA15956", "UKA16663", "UKA16097"))
#'
#'  # Case c: data frame
#'  ukair_get_coords(ukair_catalogue()[1:10,])
#'  }
#'

ukair_get_coords <- function(ids) {
  UseMethod("ukair_get_coords")
}

#' @export
ukair_get_coords.default <- function(ids) {
  stop("no available method for ", class(ids), call. = FALSE)
}

#' @export
ukair_get_coords.character <- function(ids){

  df_extended <- id2coords(ids)

  # return a data.frame with coordinates
  return(tibble::as_tibble(df_extended))

}

#' @export
ukair_get_coords.data.frame <- function(ids){

  nrows <- seq(1, dim(ids)[1])

  # By default we are expected to just infill missing coordinates
  if ("Latitude" %in% names(ids) & "Longitude" %in% names(ids)){
    nrows <- which(is.na(ids$Latitude) | is.na(ids$Longitude))
  }

  # otherwise, we force to extract coordinates for all the given id_s
  id_s <- as.character(ids$UK.AIR.ID[nrows])

  df_extended <- id2coords(id_s)

  # return the new data.frame with infilled coordinates
  rows2fill <- which(ids$UK.AIR.ID %in% df_extended$UK.AIR.ID)
  if (all(ids$UK.AIR.ID[rows2fill] == df_extended$UK.AIR.ID)){
    ids$Latitude[rows2fill] <- df_extended$Latitude
    ids$Longitude[rows2fill] <- df_extended$Longitude
  }else{
    message("Check the order!")
  }

  suppressWarnings(output <- dplyr::left_join(ids, df_extended,
                                              by = c("UK.AIR.ID",
                                                     "Latitude", "Longitude")))

  return(tibble::as_tibble(output))

}

#' Get Easting and Northing coordinates from DEFRA for 1 station
#'
#' @importFrom httr GET
#' @importFrom xml2 xml_find_all
#'
#' @noRd
#'

ukair_get_coords_internal <- function(uka_id){

  page_fetch <- httr::GET(url = "http://uk-air.defra.gov.uk",
                          path = "networks/site-info",
                          query = list(uka_id = uka_id))

  # download content
  page_content <- httr::content(page_fetch)

  # Extract tab row containing Easting and Northing
  page_tab <- xml2::xml_find_all(page_content,
                                 "//*[contains(@id,'tab_info')]")[[2]]

  # extract and clean all the columns
  vals <- trimws(xml2::xml_text(page_tab))
  # Extract string containing easting and northing
  x <- strsplit(vals, "Easting/Northing:")[[1]][2]
  x <- strsplit(x, "Latitude/Longitude:")[[1]][1]
  # split string into easting and northing and remove heading/trailing spaces
  en <- gsub("^\\s+|\\s+$", "", unlist(strsplit(x, ",")))

  if (!is.null(en)){

    en_numeric <- c("Easting" = as.numeric(en[1]),
                   "Northing" = as.numeric(en[2]))

  }else{

    en_numeric <- NULL
    message(paste("No coordinates available for station", uka_id))

  }

  return(en_numeric)

}

#' Convert Easting and Northing to Latitude and Longitude
#'
#' @importFrom sp coordinates proj4string CRS spTransform
#'
#' @noRd
#'

id2coords <- function(id_s){

  # Get Easting and Northing
  en_DF <- data.frame(t(sapply(id_s, ukair_get_coords_internal)))

  # Remove NAs
  rows_no_na <- which(!is.na(en_DF$Easting) & !is.na(en_DF$Northing))
  en_df_no_nas <- en_DF[rows_no_na, ]

  # Transform Easting and Northing to Latitude and Longitude
  # first, define spatial points
  sp::coordinates(en_df_no_nas) <- ~Easting + Northing
  sp::proj4string(en_df_no_nas) <- sp::CRS("+init=epsg:27700")
  # then, convert coordinates from British National Grid to WGS84
  latlon <- round(sp::spTransform(en_df_no_nas,
                                  sp::CRS("+init=epsg:4326"))@coords, 6)
  pt <- data.frame(latlon)
  names(pt) <- c("Longitude", "Latitude")

  df_extended <- cbind(id_s[rows_no_na], en_df_no_nas@coords, pt)
  names(df_extended)[1] <- "UK.AIR.ID"

  return(df_extended)

}
