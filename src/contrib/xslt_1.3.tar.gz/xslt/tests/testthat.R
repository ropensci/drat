library(testthat)
library(xslt)

test_check("xslt")
