scatrr
======



[![Build Status](https://travis-ci.org/ropenscilabs/scatrr.svg?branch=master)](https://travis-ci.org/ropenscilabs/scatrr)

Scholastic Commentaries and Texts Archive - <http://scta.info/>

NOT WORKING RIGHT NOW

## Meta

* Please [report any issues or bugs](https://github.com/ropenscilabs/scatrr/issues).
* License: MIT
* Get citation information for `scatr` in R doing `citation(package = 'scatrr')`
* Please note that this project is released with a [Contributor Code of Conduct](CONDUCT.md). By participating in this project you agree to abide by its terms.
