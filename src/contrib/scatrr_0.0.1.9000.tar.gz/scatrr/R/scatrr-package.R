#' scta client
#'
#' @import crul
#' @importFrom jsonlite fromJSON
#' @name scatrr-package
#' @aliases scatrr
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
