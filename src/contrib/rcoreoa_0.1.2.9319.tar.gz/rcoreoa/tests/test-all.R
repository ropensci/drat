library("testthat")
test_check("rcoreoa")
