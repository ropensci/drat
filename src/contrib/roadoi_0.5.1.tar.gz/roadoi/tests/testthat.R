library(testthat)
library(roadoi)

test_check("roadoi")
