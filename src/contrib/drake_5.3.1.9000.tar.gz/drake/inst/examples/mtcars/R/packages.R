# Here, load the packages you need for your workflow.

library(drake)
library(knitr)

pkgconfig::set_config("drake::strings_in_dots" = "literals")
