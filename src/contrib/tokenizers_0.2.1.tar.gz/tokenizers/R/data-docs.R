#' The text of Moby Dick
#'
#' The text of Moby Dick, by Herman Melville, taken from Project Gutenberg.
#'
#' @format A named character vector with length 1.
#' @source \url{http://www.gutenberg.org/}
"mobydick"
