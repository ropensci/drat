# available 1.0.1

* Filter own repo from GitHub results (#21).
* `get_urban_data()` is now exported (#34).
* No longer trimming r or R when proceeded by a vowel from search terms, as originally intended (#35).
* Support for upcoming glue 1.3.0 release

# available 1.0.0

* Initial release
