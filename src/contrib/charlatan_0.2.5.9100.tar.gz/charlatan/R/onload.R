charlatan_settings_env <- NULL
.onLoad <- function(libname, pkgname) {
  charlatan_settings_env <<- new.env()
}
