library('testthat')
library('hddtools')

test_check('hddtools')
