# RedisAPI

[![Project Status: Abandoned – Initial development has started, but there has not yet been a stable, usable release; the project has been abandoned and the author(s) do not intend on continuing development.](http://www.repostatus.org/badges/latest/abandoned.svg)](http://www.repostatus.org/#abandoned)

The functionality implemented in this package has been folded back into [`redux`](https://github.com/richfitz/redux).  Please use that package instead.  The [`rrlite`](https://github.com/ropensci/rrlite) shows how the abstracted interface can be used.

## Meta

* License: BSD (2 clause)
* Get citation information for `RedisAPI` in R by doing `citation(package = 'RedisAPI')`

[![rofooter](http://ropensci.org/public_images/github_footer.png)](http://ropensci.org)
