library(testthat)
library(colorpiler)

test_check("colorpiler")
