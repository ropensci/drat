library("testthat")
test_check("ghql")
