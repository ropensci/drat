# Here, load the packages you need for your workflow.

library(drake)
library(Ecdat) # econometrics datasets
library(knitr)
library(ggplot2)
