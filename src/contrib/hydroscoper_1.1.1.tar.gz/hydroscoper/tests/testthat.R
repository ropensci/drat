library(testthat)
library(hydroscoper)

test_check("hydroscoper")
