library(testthat)
library(rdataretriever)


test_check("rdataretriever", reporter = c("check"))
