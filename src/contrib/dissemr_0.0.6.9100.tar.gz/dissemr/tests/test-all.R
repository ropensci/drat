library("testthat")
test_check("dissemr")
