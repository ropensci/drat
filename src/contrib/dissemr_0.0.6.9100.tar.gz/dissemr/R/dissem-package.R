#' dissemr
#'
#' @name dissemr-package
#' @aliases dissemr
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
