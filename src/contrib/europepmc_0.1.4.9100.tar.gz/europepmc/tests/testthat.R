library(testthat)
library(europepmc)

test_check("europepmc")
