# geoparser 0.1.1

* Updates links to the Github repo (moved from ropenscilabs to ropensci)
