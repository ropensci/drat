context("test-load.R")

test_that("package loading works", {
  expect_silent(library(nomisr))
})
