
## Utility variables to assist query building
base_url <- "https://www.nomisweb.co.uk/api/v01/dataset/"

content_url <- "https://www.nomisweb.co.uk/api/v01/contenttype/"

codelist_url <- "https://www.nomisweb.co.uk/api/v01/codelist/"
