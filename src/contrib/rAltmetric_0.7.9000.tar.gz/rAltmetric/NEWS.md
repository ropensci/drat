# rAltmetric 0.7.9000
------------------

* Updated package after a super long time to using `httr` instead of `RCurl`
* Simplfied converting lists →  data.frames
* Added support for ISBN and URIs
* Removed plot method since it was not useful or generalizable to various identifiers

# rAltmetric 0.6
------------------
* Several bug fixes and documentation updates

# rAltmetric 0.5
------------------

* Removed hard dependencies and moved them to imports
* Minor bug fixes


# rAltmetric 0.3
------------------

* Initial release to CRAN
