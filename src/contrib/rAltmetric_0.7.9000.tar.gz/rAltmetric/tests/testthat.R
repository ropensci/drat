library(testthat)
library(rAltmetric)

test_check("rAltmetric")
