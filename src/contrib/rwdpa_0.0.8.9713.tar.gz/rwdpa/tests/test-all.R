library("testthat")
test_check("rwdpa")
