std::string replace_all_symbols(std::string x);
std::string replace_specific_symbols(std::string x);
