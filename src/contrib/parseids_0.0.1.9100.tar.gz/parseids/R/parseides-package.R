#' Parsing Expression Grammar for parsing identifiers
#' 
#' @useDynLib parseids
#' @import Rcpp
#' @name parseids-package
#' @aliases parseids
#' @docType package
#' @keywords package
NULL

#' DOIs data
#' 
#' dataset of 1000 DOIs
#' 
#' @docType data
#' @keywords data
#' @name dois
NULL
