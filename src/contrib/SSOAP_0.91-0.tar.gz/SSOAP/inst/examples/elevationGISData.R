library(SSOAP)
u = "http://gisdata.usgs.gov/XMLWebServices/TNM_Elevation_service.asmx?WSDL"

w = processWSDL(u)
