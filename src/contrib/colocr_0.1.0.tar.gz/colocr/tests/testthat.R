library(testthat)
library(shinytest)
library(colocr)

test_check("colocr")
