clean_str <- function(x) {
  gsub("\n", "", x)
}
