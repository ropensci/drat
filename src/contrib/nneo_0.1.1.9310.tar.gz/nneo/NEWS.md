nneo 0.1.0
==========

### NEW FEATURES

* Released to CRAN.
