load("ns_data_output.rda")
