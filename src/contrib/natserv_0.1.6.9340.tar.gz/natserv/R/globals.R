if (base::getRversion() >= "2.15.1") {
  utils::globalVariables(
    c("currentPresenceAbsence", "element_blank", "group", "lat", "long",
    "speciesOccurrenceCount", "theme", "unit", "nat_states")
  )
}
