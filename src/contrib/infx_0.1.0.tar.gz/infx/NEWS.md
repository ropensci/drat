infx 0.1.0 (2018-03-23)
=========================

### NEW FEATURES

  * ready for rOpenSci onboarding request