
library(testthat)
library(infx)

test_check("infx", "^feature$")
