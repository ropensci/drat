
library(testthat)
library(infx)

test_check("infx", "^(json-(class|utils|vec|base)|request|login)$")
