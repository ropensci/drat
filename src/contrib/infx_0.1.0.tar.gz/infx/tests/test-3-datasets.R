
library(testthat)
library(infx)

test_check("infx", "^dataset$")
