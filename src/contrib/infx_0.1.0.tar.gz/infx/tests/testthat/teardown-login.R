
logout_openbis(tok)