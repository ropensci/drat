
library(testthat)
library(infx)

test_check("infx", "^(experiment|material|plate|project|sample|search)$")
