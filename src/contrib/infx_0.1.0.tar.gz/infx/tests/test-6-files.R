
library(testthat)
library(infx)

test_check("infx", "^(file|url)$")
