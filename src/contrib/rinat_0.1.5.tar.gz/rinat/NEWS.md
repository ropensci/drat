rinat 0.1.5
==========

## BUG FIXES

* Fixed bug where an error occurred when >20K records were requested and code now throws a warning to not hammer the API

* Fixed warning thrown when building vignettes on Linux systems

* Fixed bug where example code parameter names were different than actual parameter names

## NEW FEATURES

* Added NEWS file.

* Added a full suite of tests

* Added new vignette that builds with markdown and not hacky prebuilt PDF