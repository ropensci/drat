library(testthat)
library("rinat")
test_check("rinat")