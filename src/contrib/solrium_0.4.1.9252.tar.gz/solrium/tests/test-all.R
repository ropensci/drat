library('testthat')
test_check('solrium')
