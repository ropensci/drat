# library("rvertnet")
# library("dplyr")

# res <- rvertnet::vertsearch(taxon = "Remora remora")$data
# res %>%
#   filter(!is.na(occurrenceremarks)) %>%
#   select(occurrenceremarks)
# re %>%
#   filter(!is.na(eventremarks)) %>%
#   select(eventremarks)
