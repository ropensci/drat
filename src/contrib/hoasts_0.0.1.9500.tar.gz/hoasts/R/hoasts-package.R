#' Host and Parasite Data Across Sources
#'
#' @name hoasts-package
#' @aliases hoasts
#' @docType package
#' @keywords package
NULL
