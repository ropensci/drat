library("testthat")
test_check("mregions")
