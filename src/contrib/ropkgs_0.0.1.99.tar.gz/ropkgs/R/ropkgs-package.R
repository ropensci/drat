#' Install rOpenSci packages
#'
#' @name ropkgs-package
#' @aliases ropkgs
#' @docType package
#' @title Install rOpenSci packages
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
