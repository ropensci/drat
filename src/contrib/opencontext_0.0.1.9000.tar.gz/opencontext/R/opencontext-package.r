#' An API client for the Open Context archaeological database
#'
#' @name opencontext
#' @docType package
#' @import httr
#' @import jsonlite
#' @import dplyr
NULL
