library(testthat)
library(opencontext)

test_check("opencontext")
