library(testthat)
library(nomisr)

test_check("nomisr")
