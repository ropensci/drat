#' This function is defunct.
#' @export
#' @rdname npn_obsspbyday-defunct
#' @keywords internal
npn_obsspbyday <- function(...) {
  .Defunct(package = "rnpn",
           msg = "the npn_obsspbyday() function no longer works, removed")
}

#' Defunct functions in rnpn
#'
#' \itemize{
#'  \item \code{\link{npn_obsspbyday}}: Removed.
#' }
#'
#' @name rnpn-defunct
NULL
