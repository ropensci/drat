library("testthat")
test_check("rnpn")
