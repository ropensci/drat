# getpublicobs.R

# getpublicobs <- 
### NO REST CALL AVAILABLE, ONLY SOAP, CAN I JUST USE SOAP, NOT SURE HOW TO DO