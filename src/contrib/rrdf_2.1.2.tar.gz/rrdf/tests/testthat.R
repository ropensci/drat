library(testthat)
library(rrdf)

test_check("rrdf")
