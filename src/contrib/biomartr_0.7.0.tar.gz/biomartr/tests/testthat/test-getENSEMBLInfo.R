context("Test: getENSEMBLInfo()")

test_that("The getENSEMBLInfo() interface works properly..",{
    
    # ENSEMBLGENOMES Info file retrieval
    getENSEMBLInfo()
})
