
#' brains
#' 
#' @return a table of species brains
#' @inheritParams species
#' @export
#' @examples \dontrun{
#' brains("Oreochromis niloticus")
#' }
brains <- endpoint("brains")
