
#' @importFrom utils globalVariables
utils::globalVariables(c("Genus", "Species", "SpecCode", "Speccode"))