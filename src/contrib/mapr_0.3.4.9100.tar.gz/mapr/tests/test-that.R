library('testthat')
test_check("mapr")
