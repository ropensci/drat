library("testthat")
test_check('rebird')
