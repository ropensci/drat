library(testthat)
test_check("rglobi")
