#' Scroll search function
#'
#' @export
#'
#' @param x (character) For \code{scroll}, a single scroll id; for
#' \code{scroll_clear}, one or more scroll id's
#' @param time_scroll (character) Specify how long a consistent view of the
#' index should be maintained for scrolled search, e.g., "30s", "1m".
#' See \code{\link{units-time}}.
#' @param raw (logical) If \code{FALSE} (default), data is parsed to list.
#' If \code{TRUE}, then raw JSON.
#' @param asdf (logical) If \code{TRUE}, use \code{\link[jsonlite]{fromJSON}}
#' to parse JSON directly to a data.frame. If \code{FALSE} (Default), list
#' output is given.
#' @param stream_opts (list) A list of options passed to
#' \code{\link[jsonlite]{stream_out}} - Except that you can't pass \code{x} as
#' that's the data that's streamed out, and pass a file path instead of a
#' connection to \code{con}. \code{pagesize} param doesn't do much as
#' that's more or less controlled by paging with ES.
#' @param all (logical) If \code{TRUE} (default) then all search contexts
#' cleared.  If \code{FALSE}, scroll id's must be passed to \code{x}
#' @param ... Curl args passed on to \code{\link[httr]{POST}}
#'
#' @seealso \code{\link{Search}}
#' @references
#' \url{https://www.elastic.co/guide/en/elasticsearch/reference/current/search-request-scroll.html}
#'
#' @return \code{scroll()} returns a list, identical to what
#' \code{\link{Search}} returns. With attribute \code{scroll} that is the
#' scroll value set via the \code{time_scroll} parameter
#'
#' \code{scroll_clear()} returns a boolean (\code{TRUE} on success)
#'
#' @section Scores:
#' Scores will be the same for all documents that are returned from a
#' scroll request. Dems da rules.
#'
#' @section Inputs:
#' Inputs to \code{scroll()} can be one of:
#' \itemize{
#'  \item list - This usually will be the output of \code{\link{Search}}, but
#'  you could in theory make a list yourself with the appropriate elements
#'  \item character - A scroll ID - this is typically the scroll id output
#'  from a call to \code{\link{Search}}, accessed like \code{res$`_scroll_id`}
#' }
#'
#' All other classes passed to \code{scroll()} will fail with message
#'
#' Lists passed to \code{scroll()} without a \code{_scroll_id} element will
#' trigger an error.
#'
#' From lists output form \code{\link{Search}} there should be an attribute
#' ("scroll") that is the \code{scroll} value set in the \code{\link{Search}}
#' request - if that attribute is missing from the list, we'll attempt to
#' use the \code{time_scroll} parameter value set in the 
#' \code{scroll()} function call
#'
#' The output of \code{scroll()} has the scroll time value as an attribute so
#' the output can be passed back into \code{scroll()} to continue.
#'
#' @section Clear scroll:
#' Search context are automatically removed when the scroll timeout has
#' been exceeded.  Keeping scrolls open has a cost, so scrolls should be
#' explicitly cleared as soon  as the scroll is not being used anymore
#' using \code{scroll_clear}
#'
#' @section Sliced scrolling:
#' For scroll queries that return a lot of documents it is possible to split
#' the scroll in multiple slices which can be consumed independently.
#'
#' See the example in this man file.
#'
#' @section Aggregations:
#' If the request specifies aggregations, only the initial search response
#' will contain the aggregations results.
#'
#' @examples \dontrun{
#' # Basic usage - can use across all indices
#' res <- Search(time_scroll="1m")
#' scroll(res)$`_scroll_id`
#'
#' # use on a specific index - and specify a query
#' res <- Search(index = 'shakespeare', q="a*", time_scroll="1m")
#' res$`_scroll_id`
#'
#' # Setting "sort=_doc" to turn off sorting of results - faster
#' res <- Search(index = 'shakespeare', q="a*", time_scroll="1m",
#'   body = '{"sort": ["_doc"]}')
#' res$`_scroll_id`
#'
#' # Pass scroll_id to scroll function
#' scroll(res$`_scroll_id`)
#'
#' # Get all results - one approach is to use a while loop
#' res <- Search(index = 'shakespeare', q="a*", time_scroll="5m",
#'   body = '{"sort": ["_doc"]}')
#' out <- list()
#' hits <- 1
#' while(hits != 0){
#'   res <- scroll(res$`_scroll_id`)
#'   hits <- length(res$hits$hits)
#'   if(hits > 0)
#'     out <- c(out, res$hits$hits)
#' }
#' length(out)
#' out[[1]]
#'
#' # clear scroll
#' ## individual scroll id
#' res <- Search(index = 'shakespeare', q="a*", time_scroll="5m",
#'   body = '{"sort": ["_doc"]}')
#' scroll_clear(res$`_scroll_id`)
#'
#' ## many scroll ids
#' res1 <- Search(index = 'shakespeare', q="c*", time_scroll="5m",
#'   body = '{"sort": ["_doc"]}')
#' res2 <- Search(index = 'shakespeare', q="d*", time_scroll="5m",
#'   body = '{"sort": ["_doc"]}')
#' nodes_stats(metric = "indices")$nodes[[1]]$indices$search$open_contexts
#' scroll_clear(c(res1$`_scroll_id`, res2$`_scroll_id`))
#' nodes_stats(metric = "indices")$nodes[[1]]$indices$search$open_contexts
#'
#' ## all scroll ids
#' res1 <- Search(index = 'shakespeare', q="f*", time_scroll="1m",
#'   body = '{"sort": ["_doc"]}')
#' res2 <- Search(index = 'shakespeare', q="g*", time_scroll="1m",
#'   body = '{"sort": ["_doc"]}')
#' res3 <- Search(index = 'shakespeare', q="k*", time_scroll="1m",
#'   body = '{"sort": ["_doc"]}')
#' scroll_clear(all = TRUE)
#'
#' ## sliced scrolling
#' body1 <- '{
#'   "slice": {
#'     "id": 0,
#'     "max": 2
#'   },
#'   "query": {
#'     "match" : {
#'       "text_entry" : "a*"
#'     }
#'   }
#' }'
#'
#' body2 <- '{
#'   "slice": {
#'     "id": 1,
#'     "max": 2
#'   },
#'   "query": {
#'     "match" : {
#'       "text_entry" : "a*"
#'     }
#'   }
#' }'
#'
#' res1 <- Search(index = 'shakespeare', time_scroll="1m", body = body1)
#' res2 <- Search(index = 'shakespeare', time_scroll="1m", body = body2)
#' scroll(res1$`_scroll_id`)
#' scroll(res2$`_scroll_id`)
#'
#' out1 <- list()
#' hits <- 1
#' while(hits != 0){
#'   tmp1 <- scroll(res1$`_scroll_id`)
#'   hits <- length(tmp1$hits$hits)
#'   if(hits > 0)
#'     out1 <- c(out1, tmp1$hits$hits)
#' }
#'
#' out2 <- list()
#' hits <- 1
#' while(hits != 0){
#'   tmp2 <- scroll(res2$`_scroll_id`)
#'   hits <- length(tmp2$hits$hits)
#'   if(hits > 0)
#'     out2 <- c(out2, tmp2$hits$hits)
#' }
#'
#' c(
#'  lapply(out1, "[[", "_source"),
#'  lapply(out2, "[[", "_source")
#' )
#'
#'
#' # using jsonlite::stream_out
#' connect()
#' res <- Search(time_scroll = "1m")
#' file <- tempfile()
#' scroll(
#'   x = res$`_scroll_id`,
#'   stream_opts = list(file = file)
#' )
#' jsonlite::stream_in(file(file))
#' unlink(file)
#'
#' ## stream_out and while loop
#' connect()
#' (file <- tempfile())
#' res <- Search(index = "shakespeare", time_scroll = "5m",
#'   size = 1000, stream_opts = list(file = file))
#' while(!inherits(res, "warning")) {
#'   res <- tryCatch(scroll(
#'     x = res$`_scroll_id`,
#'     time_scroll = "5m",
#'     stream_opts = list(file = file)
#'   ), warning = function(w) w)
#' }
#' NROW(df <- jsonlite::stream_in(file(file)))
#' head(df)
#' }
scroll <- function(x, time_scroll = "1m", raw = FALSE, asdf = FALSE,
                   stream_opts = list(), ...) {
  UseMethod("scroll")
}

#' @export
scroll.default <- function(x, time_scroll = "1m", raw = FALSE, asdf = FALSE,
                           stream_opts = list(), ...) {
  stop("no 'scroll()' method for ", class(x), call. = FALSE)
}

#' @export
scroll.list <- function(x, time_scroll = "1m", raw = FALSE, asdf = FALSE,
                        stream_opts = list(), force_scroll = FALSE, ...) {
  scroll_ <- NULL
  if (!is.null(x$`_scroll_id`)) {
    scroll_ <- attr(x, "scroll")
  } else {
    stop("when passing a list, there must be a `_scroll_id` element",
         call. = FALSE)
  }
  if (is.null(scroll_)) {
    message("didn't find 'scroll' value in attributes, using 'scroll' param")
    scroll_ <- time_scroll
  }
  if (force_scroll) scroll_ <- time_scroll
  scroll(x$`_scroll_id`, time_scroll = scroll_, raw = raw,
                   asdf = asdf, stream_opts = stream_opts, ...)
}

#' @export
scroll.character <- function(x, time_scroll = "1m", raw = FALSE, asdf = FALSE,
                             stream_opts = list(), ...) {

  calls <- names(list(...))
  if ("scroll" %in% calls) {
    stop("The parameter `scroll` has been removed - use `time_scroll`")
  }
  if (es_ver() < 200) {
    body <- x
    args <- list(scroll = time_scroll)
  } else {
    body <- list(scroll = time_scroll, scroll_id = x)
    args <- list()
  }
  tmp <- scroll_POST(
    path = "_search/scroll",
    args = args,
    body = body,
    raw = raw,
    asdf = asdf,
    stream_opts = stream_opts, ...)
  attr(tmp, "scroll") <- time_scroll
  return(tmp)
}

#' @export
#' @rdname scroll
scroll_clear <- function(x = NULL, all = FALSE, ...) {
  if (all) {
    path <- "_search/scroll/_all"
    body <- NULL
  } else {
    if (is.null(x)) stop("if all=FALSE, x must not be NULL",
                                 call. = FALSE)
    path <- "_search/scroll"
    body <- list(scroll_id = x)
  }
  scroll_DELETE(path, body = body, ...)
}
