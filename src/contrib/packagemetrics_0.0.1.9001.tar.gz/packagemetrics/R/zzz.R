utils::globalVariables(c("action", "aria-label", "bug_git", "bugreports",
                         "count", "datetime", "depends", "depends_count",
                         "dl_last_month", "github_social", "github_url",
                         "has_tests", "has_vignette_build", "imports",
                         "last_commit", "last_issue_closed", "package",
                         "published", "reverse_count", "reverse_depends",
                         "reverse_depends_count", "reverse_imports",
                         "reverse_imports_count", "stars", "suggests",
                         "tidyverse_happy", "url_git", "vignettebuilder"))
