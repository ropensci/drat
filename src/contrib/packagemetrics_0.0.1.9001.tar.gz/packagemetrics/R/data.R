#' Table of Packages
#'
#' @format A character vector of packages
"table_packages"
