library("testthat")
test_check("scitations")
