library("testthat")
test_check("cmipr")
