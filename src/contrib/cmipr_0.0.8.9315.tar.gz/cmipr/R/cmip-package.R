#' cmipr
#'
#' R client for CMIP (Coupled Model Intercomparison Project) data
#'
#' @name cmipr-package
#' @aliases cmipr
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
