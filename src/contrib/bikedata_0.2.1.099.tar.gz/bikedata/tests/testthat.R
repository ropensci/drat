library(testthat)
library(bikedata)

test_check("bikedata")
