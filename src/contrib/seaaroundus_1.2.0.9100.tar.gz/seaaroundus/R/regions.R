#' Regions details
#'
#' @name regions
#' @details Region options
#'
#' - eez
#' - lme
#' - rfmo
#' - highseas
#' - fao
#' - eez-bordering
#' - fishing-entity
#' - taxon
#' - global
NULL
