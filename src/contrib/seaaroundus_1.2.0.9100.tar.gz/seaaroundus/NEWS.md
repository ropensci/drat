seaaroundus 1.2.0
=================

### NEW FEATURES

* Released to CRAN.
