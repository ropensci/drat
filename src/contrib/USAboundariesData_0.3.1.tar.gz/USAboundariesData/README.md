
<!-- README.md is generated from README.Rmd. Please edit that file -->

# USAboundariesData

[![Travis-CI Build
Status](https://travis-ci.org/ropensci/USAboundariesData.svg?branch=master)](https://travis-ci.org/ropensci/USAboundariesData)
[![AppVeyor Build
Status](https://ci.appveyor.com/api/projects/status/github/ropensci/USAboundariesData?branch=master)](https://ci.appveyor.com/project/ropensci/USAboundariesData)

## Overview

This R package contains datasets for the
[USAboundaries](http://lincolnmullen.com/software/usaboundaries/)
package. Please see that package for documentation and installation
instructions.
