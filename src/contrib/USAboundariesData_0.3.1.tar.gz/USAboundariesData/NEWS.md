# USAboundariesData 0.3.1

- Minor changes to column names for consistency across datasets.
- `census_cities` is now an `sf` object rather than just a data frame.
