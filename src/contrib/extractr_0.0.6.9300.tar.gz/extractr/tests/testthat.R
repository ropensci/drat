library(testthat)
library(extractr)

test_check("extractr")
