sofa 0.2.0
==========

### NEW FEATURES

* released to CRAN
