library(testthat)
library(taxa)

test_check("taxa")
