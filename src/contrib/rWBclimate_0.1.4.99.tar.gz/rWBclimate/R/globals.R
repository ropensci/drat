if (base::getRversion() >= "2.15.1") {
  utils::globalVariables(c("long", "lat","group","NoAm_country","SoAm_country","Oceana_country","Africa_country","Asia_country","Eur_country"))
}
