rnaturalearthhires
==================

An R package to store data for the [rnaturalearth](https://github.com/ropenscilabs/rnaturalearth) package.


[![ropensci\_footer](http://ropensci.org/public_images/github_footer.png)](http://ropensci.org)
