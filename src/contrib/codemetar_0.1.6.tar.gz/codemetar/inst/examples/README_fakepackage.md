
<!-- README.md is generated from README.Rmd. Please edit that file -->

# fakepackage

[![Travis build status](https://travis-ci.org/fakeorg/fakepackage.svg?branch=master)](https://travis-ci.org/fakeorg/fakepackage)
[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/fakeorg/fakepackage?branch=master&svg=true)](https://ci.appveyor.com/project/fakeorg/fakepackage)
[![Coverage status](https://codecov.io/gh/fakeorg/fakepackage/branch/master/graph/badge.svg)](https://codecov.io/github/fakeorg/fakepackage?branch=master)
[![CRAN status](http://www.r-pkg.org/badges/version/fakepackage)](https://cran.r-project.org/package=fakepackage)
[![lifecycle](https://img.shields.io/badge/lifecycle-stable-brightgreen.svg)](https://www.tidyverse.org/lifecycle/#stable)
