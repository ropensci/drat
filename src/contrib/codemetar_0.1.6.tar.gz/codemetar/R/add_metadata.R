#
#
# ## Some preliminary helper functions to add additional metadata
#
#
# ## simple, top-level items
# add_metadata <-
#   function(codemeta,
#            keywords,
#            developmentStatus,
#            dateModified,
#            datePublished,
#            embargoDate,
#            funding) {
#   }
