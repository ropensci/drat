library(testthat)
library(codemetar)

test_check("codemetar")
