library(testthat)
library(comtradr)

test_check("comtradr")
