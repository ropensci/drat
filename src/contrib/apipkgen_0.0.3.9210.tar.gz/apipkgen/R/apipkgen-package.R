#' apipkgen
#'
#' @import yaml
#' @name apipkgen-package
#' @aliases apipkgen
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
