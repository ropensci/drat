scrubr 0.1.1
============

### MINOR IMPROVEMENTS

* Fixed examples to be conditional on presence of `rgbif` (#17)
* Fix `as.matrix()` to use `Matrix::as.matrix()`

scrubr 0.1.0
============

### NEW FEATURES

* Releasd to CRAN.
