location data
=============

* herbaria.csv - modified from https://github.com/ejedwards/reanalysis_zanne2014
