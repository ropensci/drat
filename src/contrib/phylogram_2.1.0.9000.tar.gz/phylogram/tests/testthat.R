library(testthat)
library(phylogram)

test_check("phylogram")
