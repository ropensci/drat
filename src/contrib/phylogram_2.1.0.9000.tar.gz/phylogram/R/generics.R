setGeneric("as.phylo")
setGeneric("as.dendrogram")

