#' rbace - Bielefeld Academic Search Engine Client
#'
#' @name rbace-package
#' @aliases rbace
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
