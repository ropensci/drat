library(testthat)
test_check("rbace")
