library(testthat)
library(jsonvalidate)

test_check("jsonvalidate")
