ckanr 0.1.0
===============

### NEW FEATURES

* Releasd to CRAN.
