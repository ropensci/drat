#' bmc package
#'
#' @name bmc
#' @docType package
NULL