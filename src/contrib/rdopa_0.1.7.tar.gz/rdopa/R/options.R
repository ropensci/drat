.options <- new.env()

assign("cache", "rdopa.Rcache", envir=.options)
