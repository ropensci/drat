<!--
%\VignetteEngine{knitr::knitr}
%\VignetteIndexEntry{An introduction to the fulltext package}
%\VignetteEncoding{UTF-8}
-->

# fulltext vignette


```r
print("Hello world!")
```

```
## [1] "Hello world!"
```
