library(testthat)
library(internetarchive)

test_check("internetarchive")
