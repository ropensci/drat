#' List accepted metadata fields
#' @return A list of the accepted metadata fields
#' @examples
#' ia_list_fields()
#' @export
ia_list_fields <- function() {
  ia_fields
}