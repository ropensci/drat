# internetarchive 0.1.6

- Fix failing test related to change at Internet Archive

# internetarchive 0.1.5

- Update package dependencies

# internetarchive 0.1.4

- Add `rmarkdown` as a suggested package since `knitr` has changed for vignettes

# internetarchive 0.1.2

- First CRAN release
- Tests and minor bugfixes

# internetarchive 0.1.1

- First public release on GitHub with rOpenSci
- Functions for searching, downloading, metadata
