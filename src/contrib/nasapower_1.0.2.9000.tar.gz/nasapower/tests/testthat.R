library(testthat)
library(nasapower)

test_check("nasapower")
