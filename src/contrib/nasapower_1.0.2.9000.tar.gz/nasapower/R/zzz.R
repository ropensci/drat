# load parameters data frame in session
data("parameters", envir = environment()) # nocov
