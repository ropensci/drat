# dirdf

[![Build Status](https://travis-ci.org/ropenscilabs/dirdf.svg?branch=master)](https://travis-ci.org/ropenscilabs/dirdf) 
[![codecov](https://codecov.io/gh/ropenscilabs/dirdf/badge.svg)](https://codecov.io/gh/ropenscilabs/dirdf)

Create tidy data frames of file metadata from directory and
file names.

## Install

```r
# install.packages("devtools")
devtools::install_github("ropenscilabs/dirdf")
```

## [Intro](https://rawgit.com/ropenscilabs/dirdf/fad6a18194978f349dc13639728c00522cea8a94/vignettes/slides.html)
