library("dirdf")

if (require("testthat")) {
  test_check("dirdf")
}
