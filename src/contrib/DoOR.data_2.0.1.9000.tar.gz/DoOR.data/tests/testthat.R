library(testthat)
library(DoOR.data)

test_check("DoOR.data")
