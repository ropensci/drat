library(testthat)
library(iheatmapr)

test_check("iheatmapr")
