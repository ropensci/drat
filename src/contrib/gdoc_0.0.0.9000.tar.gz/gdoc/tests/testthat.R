library(testthat)
library(gdoc)

test_check("gdoc")
