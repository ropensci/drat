library(testthat)
library(landscapetools)

test_check("landscapetools")
