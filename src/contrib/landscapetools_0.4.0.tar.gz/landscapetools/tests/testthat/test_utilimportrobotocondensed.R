# nolint start

context("util_import_roboto_condensed")

test_that("basic functionality", {
  skip_on_cran()
  expect_error(util_import_roboto_condensed(), NA)
})

# nolint end
