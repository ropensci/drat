library("testthat")
test_check("dissem")
