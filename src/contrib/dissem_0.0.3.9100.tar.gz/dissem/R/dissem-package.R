#' dissem
#'
#' @name dissem-package
#' @aliases dissem
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
