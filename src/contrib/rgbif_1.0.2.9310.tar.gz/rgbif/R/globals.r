if (base::getRversion() >= "2.15.1") {
  utils::globalVariables(c("long","lat","group","longitude","latitude","name","keys","decimalLatitude","decimalLongitude","gbifissues","isocodes"))
}
