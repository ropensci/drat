#' This function is defunct.
#' @export
#' @rdname citations-defunct
#' @keywords internal
citations <- function(...) {
  .Defunct(msg = "the data provider behind citations() is gone")
}
