microdemic 0.2.0
================

### NEW FEATURES

* Many of the functions gain a new parameter `model` with value of 
'latest' or 'beta-2015'. 


microdemic 0.1.0
================

### NEW FEATURES

* released to CRAN
