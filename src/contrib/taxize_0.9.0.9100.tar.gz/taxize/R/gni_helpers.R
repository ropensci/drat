checknull <- function(x) {
  if (is.null(x)) {
    "none"
  } else{
    x
  }
}

gni_base <- function() "http://gni.globalnames.org/"
