#' Metro Data
#'
#' This data comes from the RITA/Transtats database
#'
#' @format A dataframe with 5802 observations and 2 variables
#' @name MetroLookup
#'
NULL

#' Metro (Full) Data
#'
#' This data comes from the RITA/Transtats database
#'
#' @format A dataframe with 5802 observations and 5 variables
#' @name MetroFull
#'
NULL
