#' Carrier data
#'
#' This data comes from the RITA/Transtats database
#'
#' @format A dataframe with 1738 observations and 2 variables
#' @name carriers
#'
NULL
