microdemic 0.4.0
================

### MINOR IMPROVEMENTS

* do testing with `vcr` (#5) (#6)
* make the output of `ma_abstract()` a data.frame and add `Id` column to 
facilitate matching to other data (#4)

microdemic 0.3.0
================

### MINOR IMPROVEMENTS

* Improve docs on how to use and get API keys (#3)
* Change base URL from `westus.api.cognitive.microsoft.com` to `api.labs.cognitive.microsoft.com`. Because of this change, you need to get use an API key from a the microsoft labs website. Get a key at <https://labs.cognitive.microsoft.com/en-us/subscriptions> and see `?microdemic-package` for details on how to use it (#2)


microdemic 0.2.0
================

### NEW FEATURES

* Many of the functions gain a new parameter `model` with value of 
'latest' or 'beta-2015'. 


microdemic 0.1.0
================

### NEW FEATURES

* released to CRAN
