library(testthat)
library(GSODR)

test_check("GSODR")
