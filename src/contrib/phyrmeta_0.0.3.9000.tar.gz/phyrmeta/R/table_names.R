table_names <- c(
  'traditional_summary_fit',
  'traditional_summary_pooled_effects',
  'phylogenetic_summary_fit',
  'phylogenetic_summary_pooled_effects',
  'traditional_vs_phylogenetic'
)