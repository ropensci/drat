#' Client to Handle Phylometa Output
#'
#' @name phyrmeta-package
#' @aliases phyrmeta
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
