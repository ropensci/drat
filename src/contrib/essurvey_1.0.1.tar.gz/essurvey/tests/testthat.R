library(testthat)
library(essurvey)

test_check("essurvey")