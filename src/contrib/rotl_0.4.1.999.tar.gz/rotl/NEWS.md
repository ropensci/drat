## rotl 0.4.1.999

## rotl 0.4.1

* Initial CRAN release on July, 24th 2015
