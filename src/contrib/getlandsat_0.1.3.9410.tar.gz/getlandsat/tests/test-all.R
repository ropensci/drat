library("testthat")
library("getlandsat")

test_check("getlandsat")
