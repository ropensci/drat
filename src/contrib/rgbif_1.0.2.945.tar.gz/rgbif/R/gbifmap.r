# See R/defunct.R
