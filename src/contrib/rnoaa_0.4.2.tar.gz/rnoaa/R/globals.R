if(getRversion() >= "2.15.1")
  utils::globalVariables(c('storm_columns','storm_names','value','id','element','day'))
