library(testthat)
library(EndoMineR)

test_check("EndoMineR")
