# EndoMineR 0.0.0.9000

* First commit to the NEWS. Further iterations planned pending testing



