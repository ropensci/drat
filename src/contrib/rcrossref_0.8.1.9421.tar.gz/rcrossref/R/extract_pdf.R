#' Extract text from a single pdf document.
#' @export
#' @keywords internal
#' @note see `crminer::crm_extract`
#' @rdname extract_xpdf-defunct
extract_xpdf <- function(...){
  .Defunct(package = "crminer", msg = "Removed - see crminer::crm_extract()")
}
