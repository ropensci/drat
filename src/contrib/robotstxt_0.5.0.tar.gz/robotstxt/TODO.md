# Todo

## integrate spiderbar into robotstxt

- include can_fetch() as option for paths_allowed()
--> restructure needed
--> setting both user-agent and curl option

- include/re-expport/(rename) other functions 

