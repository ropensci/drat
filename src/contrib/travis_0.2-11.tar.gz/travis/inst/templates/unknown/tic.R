# TODO: Define steps using the tic DSL
# get_stage("<stage name>") %>%
#   add_step(step_...(...))
