# riem 0.1.1

* Eliminates a few dependencies (dplyr, lazyeval, readr) to make installation easier.

* Now the default end date for `riem_measures` is the current date as given by `Sys.Date()`.

# riem 0.1.0

* Added a `NEWS.md` file to track changes to the package.



