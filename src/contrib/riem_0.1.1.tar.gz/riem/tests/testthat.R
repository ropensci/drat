library(testthat)
library(riem)

test_check("riem")
