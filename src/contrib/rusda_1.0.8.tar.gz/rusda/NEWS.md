rusda 1.0.8
==============

### IMROVEMENTS
* now the user can also provide a genus name or multiple of them. Then Linnean Species names are downloaded from the NCBI taxonomy and used as query input.
* added tests, e.g. if USDA website is available
* updated vignette