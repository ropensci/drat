#' atomize
#'
#' @importFrom functionMap map_r_package
#' @importFrom devtools create document
#' @name atomize-package
#' @aliases atomize
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
