library(testthat)
test_check("crevents")
