`%||%` <- function(x, y) {
  if (is.null(x) || length(x) == 0) y else x
}
