if (base::getRversion() >= "2.15.1") {
  utils::globalVariables(c("country_code_data", "species_code_data"))
}