library(testthat)
library(testdat)

test_check("testdat")
