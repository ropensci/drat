setClass(
  "OneKP",
  representation(
    table = "data.frame",
    links = "data.frame"
  )
)
