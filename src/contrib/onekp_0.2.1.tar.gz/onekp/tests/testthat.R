library(testthat)
library(onekp)

test_check("onekp")
