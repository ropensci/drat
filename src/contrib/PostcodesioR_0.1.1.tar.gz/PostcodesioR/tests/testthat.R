library(testthat)
library(PostcodesioR)

test_check("PostcodesioR")
