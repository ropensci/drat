library(testthat)
library(ropenaq)

test_check("ropenaq")
