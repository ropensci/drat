getlandsat 0.2.0
================

### MINOR IMPROVEMENTS

* moved to using markdown docs (#21)
* changed to using `crul` for HTTP requests (#20)


getlandsat 0.1.0
================

### NEW FEATURES

* Released to CRAN.
