library(testthat)
library(rperseus)

test_check("rperseus")
