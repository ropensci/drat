context("Search patient index in a record")
test_that("Search patient index in a record",
{

    #a <-function(b)
#b['NULL']
#a(ccd@nhs_numbers)

})

