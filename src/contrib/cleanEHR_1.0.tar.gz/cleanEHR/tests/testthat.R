library(testthat)
library(cleanEHR)


test_check("cleanEHR")
