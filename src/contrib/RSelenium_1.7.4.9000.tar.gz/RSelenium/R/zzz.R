# .onAttach <- function(libname, pkgname) {
#   source("selKeys.R", encoding="UTF-8") 
# }