library(testthat)
library(rrlite)

test_check("rrlite")
