#include <stdint.h>

uint64_t rl_crc64(uint64_t crc, const unsigned char *s, uint64_t l);
