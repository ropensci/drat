#include "rlite.h"

int rl_create_signal(const char *signal_name) {
	return RL_NOT_IMPLEMENTED;
}

int rl_delete_signal(const char *signal_name) {
	return RL_NOT_IMPLEMENTED;
}

int rl_read_signal(const char *signal_name, char **_data, size_t *_datalen) {
	return RL_NOT_IMPLEMENTED;
}

int rl_write_signal(const char *signal_name, const char *data, size_t datalen) {
	return RL_NOT_IMPLEMENTED;
}
