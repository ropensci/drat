#include "rlite.h"

int rl_flock(FILE *fp, int type) {
	// TODO: implement flock
	return RL_OK;
}
