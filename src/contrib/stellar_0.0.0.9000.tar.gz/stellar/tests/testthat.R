library(testthat)
library(stellar)

test_check("stellar")
