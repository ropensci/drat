#' Search Catalogue of Life for taxonomic classifications.
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @export
#' @rdname col_classification-defunct
#' @keywords internal
col_classification <- function(...) {
  .Defunct(msg = "This function is defunct. See classification().")
}
