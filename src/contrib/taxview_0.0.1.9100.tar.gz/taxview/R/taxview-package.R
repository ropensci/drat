#' Tools for Vizualizing Data Taxonomically
#'
#' @import dplyr 
#' @importFrom taxize classification
#' @importFrom tidyr nest
#' @name taxview-package
#' @aliases taxview
#' @docType package
#' @keywords package
NULL
