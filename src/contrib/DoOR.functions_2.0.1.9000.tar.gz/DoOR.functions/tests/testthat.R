library(testthat)
library(DoOR.functions)

test_check("DoOR.functions")
