library("testthat")
test_check("rdryad")
