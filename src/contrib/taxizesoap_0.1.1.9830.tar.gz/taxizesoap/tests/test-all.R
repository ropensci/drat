library(testthat)
library("taxizesoap")
test_check("taxizesoap")
