if (getRversion() >= "2.15.1") {
  utils::globalVariables(c('pesi_iface', 'worms_iface'))
}
