mssg <- function(v, ...) if(v) message(...)
tsc <- function (l) Filter(Negate(is.null), l)
