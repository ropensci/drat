#' @export
#' @rdname listDatabases
listNCBIDatabases <- listDatabases
