library(testthat)
library(biomartr)
library(magrittr)

test_check("biomartr")
