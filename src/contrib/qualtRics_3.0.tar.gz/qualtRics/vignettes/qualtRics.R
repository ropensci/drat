## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, out.width="80%"----------------------------------------
knitr::include_graphics("https://raw.githubusercontent.com/ropensci/qualtRics/master/img/config_step1.png")

## ---- echo=FALSE, out.width="80%"----------------------------------------
knitr::include_graphics("https://raw.githubusercontent.com/ropensci/qualtRics/master/img/config_step2.png")

## ---- echo=FALSE, out.width="80%"----------------------------------------
knitr::include_graphics("https://raw.githubusercontent.com/ropensci/qualtRics/master/img/qualtricsdf.png")

