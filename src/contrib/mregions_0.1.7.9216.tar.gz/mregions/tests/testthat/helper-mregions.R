strext <- function(str, pattern) regmatches(str, regexpr(pattern, str))
