library("testthat")
library("traits")

test_check("traits")
