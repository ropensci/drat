library("testthat")
test_check("worrms")
