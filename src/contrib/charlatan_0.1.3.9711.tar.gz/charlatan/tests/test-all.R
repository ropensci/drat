library("testthat")
test_check("charlatan")
