rif 0.2.0
=========

### NEW FEATURES

* This is mostly not user-facing, but NIF has a new base URL
for their API, but the routes and thus the functions in
this package are all the same. (#8)
* All funtions gain a new parameter `key` for passing in an
API key. After installation, see docs for how to get an API
key (#9)



rif 0.1.0
=========

* Released to CRAN.
