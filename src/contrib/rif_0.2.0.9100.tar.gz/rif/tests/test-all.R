library(testthat)
library(rif)

test_check("rif")
