
globalVariables(".")
