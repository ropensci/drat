helminthR 1.0.5
==============

### NEW FEATURES

* Released to CRAN.
