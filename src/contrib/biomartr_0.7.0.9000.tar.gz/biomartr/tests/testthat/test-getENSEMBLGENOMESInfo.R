context("Test: getENSEMBLGENOMESInfo()")

test_that("The getENSEMBLGENOMESInfo() interface works properly..",{
    
    # ENSEMBLGENOMES Info file retrieval
    getENSEMBLGENOMESInfo()
})
