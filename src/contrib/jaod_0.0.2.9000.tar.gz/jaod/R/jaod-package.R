#' jaod
#'
#' @name jaod-package
#' @aliases jaod
#' @docType package
#' @keywords package
NULL
