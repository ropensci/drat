library(testthat)

test_check("dbhydroR")
