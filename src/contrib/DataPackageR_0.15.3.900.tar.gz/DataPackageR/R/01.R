.onLoad <- function(libname, pkgname) {
  options("DataPackageR_interact" = interactive())
}
