#' @import shiny
#' @import ggplot2
#' @importFrom plotly ggplotly layout plotlyOutput event_data renderPlotly style
#' @importFrom shinyjs useShinyjs runjs
#' @import dplyr
#' @import ggthemes
#' @importFrom tidyr gather
#' @importFrom graphics text segments points polygon plot
#' @importFrom stats dist
#' @importFrom methods as
#' 
NULL
