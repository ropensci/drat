#' @import shiny
#' @import ggplot2
#' @importFrom plotly ggplotly layout plotlyOutput event_data renderPlotly style
#' @importFrom colourpicker colourInput
#' @import dplyr
#' @import ggthemes
#' @importFrom tidyr gather
#' @importFrom graphics text segments points polygon plot
#' @importFrom stats dist
#' @importFrom methods as
#' 
NULL
