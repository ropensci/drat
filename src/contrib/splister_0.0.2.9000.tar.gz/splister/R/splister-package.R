#' Match Species Lists Against Reference List
#'
#' @importFrom readr read_csv
#' @importFrom digest digest
#' @name splister-package
#' @aliases splister
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
