#' Interface to the ftdoi.org API for publisher url patterns.
#' 
#' @importFrom jsonlite fromJSON
#' @importFrom crul HttpClient
#' @name rftdoi-package
#' @aliases rftdoi
#' @docType package
#' @keywords package
NULL
