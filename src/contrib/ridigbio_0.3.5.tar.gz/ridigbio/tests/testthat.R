library(testthat)
library(ridigbio)

test_check("ridigbio")
