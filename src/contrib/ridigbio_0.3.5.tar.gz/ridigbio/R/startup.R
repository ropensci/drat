##' Display startup message while in beta
##' 
.onAttach <- function(...) {
  #packageStartupMessage("ridigbio works against the BETA API! Please report errors at https://github.com/iDigBio/ridigbio/issues")
}
