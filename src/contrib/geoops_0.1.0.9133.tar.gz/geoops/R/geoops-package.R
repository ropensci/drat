#' geoops
#'
#' @useDynLib geoops
#' @importFrom Rcpp sourceCpp
#' @name geoops-package
#' @aliases geoops
#' @docType package
#' @keywords package
NULL
