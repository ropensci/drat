#' Metadata providers data.frame.
#' @name providers
#' @docType data
#' @keywords datasets
NULL

#' Metadata providers data.frame.
#' @name dpla_fields
#' @docType data
#' @keywords datasets
NULL
