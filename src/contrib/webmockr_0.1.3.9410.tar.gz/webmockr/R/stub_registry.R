#' List stubs in the stub registry
#'
#' @export
#' @return an object of class `StubRegistry`, print method gives the
#' stubs in the registry
#' @family stub-registry
stub_registry <- function() webmockr_stub_registry
