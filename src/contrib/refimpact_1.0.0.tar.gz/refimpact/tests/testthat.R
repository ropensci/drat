library(testthat)
library(refimpact)

test_check("refimpact")
