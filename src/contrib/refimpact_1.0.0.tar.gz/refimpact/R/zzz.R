.onAttach <- function(libname, pkgname) {
  packageStartupMessage(
    "refimpact: API wrapper for the UK REF 2014 Impact Case ",
    "Studies Database.\nRun ?refimpact for help, or see the vignette.")
}
