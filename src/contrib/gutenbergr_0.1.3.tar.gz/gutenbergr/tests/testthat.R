library(testthat)
library(gutenbergr)

test_check("gutenbergr")
