library(testthat)
library(rrricanes)

test_check("rrricanes")
