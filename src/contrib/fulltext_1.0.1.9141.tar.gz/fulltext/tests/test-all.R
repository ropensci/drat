library("testthat")
test_check("fulltext")
