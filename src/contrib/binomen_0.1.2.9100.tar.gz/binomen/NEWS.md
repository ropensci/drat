binomen 0.1.2
===============

### MINOR IMPROVEMENTS

* Fix for new version of `dplyr` coming out.


binomen 0.1.0
===============

### NEW FEATURES

* Releasd to CRAN.
