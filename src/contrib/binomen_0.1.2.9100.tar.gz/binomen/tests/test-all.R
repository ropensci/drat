library("testthat")
test_check("binomen")
