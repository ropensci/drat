library(testthat)
library(rppo)

test_check("rppo")
