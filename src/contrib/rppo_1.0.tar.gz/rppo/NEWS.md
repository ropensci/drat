# rppo 1.0
## New Features
 * released to CRAN on May 8th, 2018

