#' HTTP Error Helpers
#'
#' @name fauxpas-package
#' @aliases fauxpas
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
