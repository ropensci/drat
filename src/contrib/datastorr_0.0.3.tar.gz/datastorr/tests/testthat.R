library(testthat)
library(datastorr)

test_check("datastorr")
