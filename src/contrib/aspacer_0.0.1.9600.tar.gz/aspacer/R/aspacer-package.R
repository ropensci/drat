#' aspacer - ArchiveSpace R client
#'
#' @importFrom httr GET POST content stop_for_status add_headers
#' @importFrom jsonlite fromJSON
#' @name aspacer-package
#' @aliases aspacer
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
