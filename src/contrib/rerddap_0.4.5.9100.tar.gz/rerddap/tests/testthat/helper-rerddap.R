# set up vcr
library("vcr")
invisible(vcr::vcr_configure(dir = "../vcr_cassettes"))
