library("testthat")
test_check("ridb")
