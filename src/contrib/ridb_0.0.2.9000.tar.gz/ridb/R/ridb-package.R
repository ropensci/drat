#' ridb - Index Database R client
#'
#' @name ridb-package
#' @aliases ridb
#' @docType package
#' @keywords package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @author David LeBauer \email{dlebauer@@gmail.com}
NULL
