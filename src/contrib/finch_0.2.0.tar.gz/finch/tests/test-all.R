library('testthat')
library('finch')

test_check('finch')
