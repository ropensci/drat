#' scta client
#'
#' @import crul
#' @importFrom jsonlite fromJSON
#' @name scatr-package
#' @aliases scatr
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
