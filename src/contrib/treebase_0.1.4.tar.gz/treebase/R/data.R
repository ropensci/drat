#' treebase.rda
#'
#' Contains a cache of all phylogenies \code{cache_treebase()} function was able
#' to pull down when run  on 2012-05-14.  
#' @name treebase
#' @docType data
#' @keywords data
#' @details recreate with: \code{
#'  cache_treebase() 
#' }
#'
NULL

#' metadata.rda
#'
#' Contains a cache of all publication metadata the search_metadata()
#' to pull down when run  on 2012-05-12.  
#' @name metadata 
#' @docType data
#' @keywords data
#' @details recreate with: \code{
#'  search_metadata() 
#' }
#'
NULL


