test_that("package loads successfully", {
          status = require("treebase")
          expect_true(status)
})
