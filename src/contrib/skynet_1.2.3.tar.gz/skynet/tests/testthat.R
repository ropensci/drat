library(testthat)
library(skynet)

test_check("skynet")
