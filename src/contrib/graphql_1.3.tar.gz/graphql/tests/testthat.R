library(testthat)
library(graphql)

test_check("graphql")
