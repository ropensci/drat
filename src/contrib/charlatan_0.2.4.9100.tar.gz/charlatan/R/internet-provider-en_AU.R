# modified from the python library faker:
# https://github.com/joke2k/faker/blob/master/faker/providers/internet/en_AU/__init__.py

int_free_email_domains_en_au = c(
  'gmail.com',
  'yahoo.com',
  'hotmail.com',
  'yahoo.com.au',
  'hotmail.com.au'
)

int_tlds_en_au = c('com', 'com.au', 'org', 'org.au', 'net',
        'net.au', 'biz', 'info', 'edu', 'edu.au')
