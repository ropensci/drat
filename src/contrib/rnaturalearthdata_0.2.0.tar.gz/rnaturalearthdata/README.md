[![Travis-CI Build Status](https://travis-ci.org/ropensci/rnaturalearthdata.svg?branch=master)](https://travis-ci.org/ropensci/rnaturalearthdata)

# rnaturalearthdata

An R package to store data for the [rnaturalearth](https://github.com/ropensci/rnaturalearth) package.


[![ropensci\_footer](http://ropensci.org/public_images/github_footer.png)](http://ropensci.org)
