rnaturalearthdata 0.2.0
===================

* update data to new version [Natural Earth v4.1](https://www.naturalearthdata.com/blog/miscellaneous/natural-earth-v4-1-0-release-notes/) released May 2018.


rnaturalearthdata 0.1.0  CRAN
=========================

* Initial release
