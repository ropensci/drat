library(testthat)
library(bomrang)

test_check("bomrang")
