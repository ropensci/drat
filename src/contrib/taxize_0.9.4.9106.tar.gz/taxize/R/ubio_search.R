#' This function will return NameBankIDs that match given search terms
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @rdname ubio_search-defunct
#' @export
#' @param ... Parameters, ignored
ubio_search <- function(...) {
  .Defunct(msg = "the uBio API is down, for good as far as we know")
}
