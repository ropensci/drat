if(getRversion() >= "2.15.1")
  utils::globalVariables(c('apg_families','apg_orders','rank_ref','theplantlist'))
