library("testthat")
test_check("rjsonapi")
