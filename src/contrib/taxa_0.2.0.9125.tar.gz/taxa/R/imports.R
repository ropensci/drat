#' magrittr forward-pipe operator
#' @name %>%
#' @importFrom magrittr %>%
#' @export
#' @keywords internal
NULL


#' dplyr select_helpers
#' @name starts_with
#' @importFrom dplyr starts_with
#' @export
#' @keywords internal
NULL

#' dplyr select_helpers
#' @name ends_with
#' @importFrom dplyr ends_with
#' @export
#' @keywords internal
NULL

#' dplyr select_helpers
#' @name contains
#' @importFrom dplyr contains
#' @export
#' @keywords internal
NULL

#' dplyr select_helpers
#' @name matches
#' @importFrom dplyr matches
#' @export
#' @keywords internal
NULL

#' dplyr select_helpers
#' @name num_range
#' @importFrom dplyr num_range
#' @export
#' @keywords internal
NULL

#' dplyr select_helpers
#' @name one_of
#' @importFrom dplyr one_of
#' @export
#' @keywords internal
NULL

#' dplyr select_helpers
#' @name everything
#' @importFrom dplyr everything
#' @export
#' @keywords internal
NULL