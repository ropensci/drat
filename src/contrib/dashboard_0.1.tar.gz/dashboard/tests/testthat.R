library(testthat)
library(dashboard)

test_check("dashboard")
