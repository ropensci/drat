# devtools::install_github("cloudyr/aws.ec2")
# install.packages("aws.ec2", repos = c(getOption("repos"), "http://cloudyr.github.io/drat"))
# library(aws.ec2)

## THIS WILL BE SOME CODE

## SUCCESSFULLY PUSHING FROM RSTUDIO!!!
