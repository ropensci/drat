#' snowball: A package for creating and running a remote cluster
#'
#' Starts an instance as a head node, then spawns worker instances for calculations. Created at the 2016 ROpenSci #auunconf.
#'
#' @section cluster functions:
#' The cluster functions ...
#'
#' @section interrogation functions:
#' The interrogation functions ...
#'
#' @docType package
#' @name snowball
NULL
