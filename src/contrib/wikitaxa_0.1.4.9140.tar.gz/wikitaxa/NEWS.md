wikitaxa 0.1.4
==============

## NEW FEATURES

* `wt_wikipedia()` and `wt_wikipedia_search()` gain parameter `wiki`
to give the wiki language, which defaults to `en` (#9)

### MINOR IMPROVEMENTS

* move some examples to dontrun (#11)


wikitaxa 0.1.0
==============

## NEW FEATURES

* Released to CRAN
