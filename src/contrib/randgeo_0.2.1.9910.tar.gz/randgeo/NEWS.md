randgeo 0.2.0
=============

### NEW FEATURES

All changes thanks to @noamross, and come from (#6) (#7)

Internals of the package are re-worked to have the features:

* Random points are now evenly distributed on the sphere
* Random shape vertex distances from the center are now based on equal-scale 
great-circle arcs
* Everything is in units of degrees latitude (e.g., ~69 miles or 111 km)

### MINOR IMPROVEMENTS

* More tests were added


randgeo 0.1.0
=============

### NEW FEATURES

* Released to CRAN.
