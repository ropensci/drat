#' rresync - Client for ResourceSync
#' 
#' @importFrom jsonlite fromJSON
#' @importFrom crul HttpClient
#' @name rresync-package
#' @aliases rresync
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
