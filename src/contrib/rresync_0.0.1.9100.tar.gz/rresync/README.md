rresync
=======



[![Build Status](https://travis-ci.org/ropenscilabs/rresync.svg?branch=master)](https://travis-ci.org/ropenscilabs/rresync)
[![codecov.io](https://codecov.io/github/ropenscilabs/rresync/coverage.svg?branch=master)](https://codecov.io/github/ropenscilabs/rresync?branch=master)
[![rstudio mirror downloads](http://cranlogs.r-pkg.org/badges/rresync)](https://github.com/metacran/cranlogs.app)
[![cran version](http://www.r-pkg.org/badges/version/rresync)](https://cran.r-project.org/package=rresync)

`rresync` - a general purpose R client for the [ResourceSync Framework](http://www.openarchives.org/rs/1.1/resourcesync)


## Install

Development version


```r
devtools::install_github("ropenscilabs/rresync")
```


```r
library("rresync")
```

## xxxx

xxxx


```r
"xxx"
#> [1] "xxx"
```

## Meta

* Please [report any issues or bugs](https://github.com/ropenscilabs/rresync/issues).
* License: MIT
* Get citation information for `rresync` in R doing `citation(package = 'rresync')`
* Please note that this project is released with a [Contributor Code of Conduct](CODE_OF_CONDUCT.md). By participating in this project you agree to abide by its terms.

[docs]: http://apiv3.iucnredlist.org/api/v3/docs
[token]: http://apiv3.iucnredlist.org/api/v3/token
