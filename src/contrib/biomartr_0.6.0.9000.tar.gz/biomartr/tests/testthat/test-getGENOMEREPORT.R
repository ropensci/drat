context("Test: getGENOMEREPORT()")

test_that("The getGENOMEREPORT() interface works properly..",{
    
    # NCBI GENOMEREPORT Info file retrieval
    getGENOMEREPORT()
})
