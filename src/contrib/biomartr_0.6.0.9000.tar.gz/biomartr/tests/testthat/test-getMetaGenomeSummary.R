context("Test: getMetaGenomeSummary()")

test_that("The getMetaGenomeSummary() interface works properly..",{
    getMetaGenomeSummary()
})
