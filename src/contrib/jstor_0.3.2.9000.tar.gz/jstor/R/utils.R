release_questions <- function() {
 paste("Have you updated the journal database and the corresponding date in",
       "the documentation?")
}
