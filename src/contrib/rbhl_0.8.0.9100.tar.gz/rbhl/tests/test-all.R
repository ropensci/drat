library("testthat")
require("jsonlite", warn.conflicts = FALSE, quietly = TRUE)
library("xml2")

test_check("rbhl")
