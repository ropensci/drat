library(testthat)
library(biomartr)

test_check("biomartr")
