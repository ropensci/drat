# devel

-  Raw reponses from GitHub are returned as raw vector
-  Responses may be wrtten to disk by providing a path in the `destfile`
   argument

# 1.0.1

First public release.
