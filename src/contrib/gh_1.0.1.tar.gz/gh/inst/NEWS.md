# devel

-  Raw reponses from GitHub are returned as raw vector

# 1.0.1

First public release.
