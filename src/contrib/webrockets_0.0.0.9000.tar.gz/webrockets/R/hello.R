#' @useDynLib webrockets
#' @importFrom Rcpp sourceCpp
NULL
