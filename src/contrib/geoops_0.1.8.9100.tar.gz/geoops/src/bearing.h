double bearing(std::string start, std::string end);
