geoops 0.1.8
============

### IMPROVEMENTS

* Don't ignore pragma warnings in `json.h`
* Updated json C++ library from [v2.1.1](https://github.com/nlohmann/json/releases/tag/v2.1.1) to [v3.1.1](https://github.com/nlohmann/json/releases/tag/v3.1.1). ([#15](https://github.com/ropensci/geoops/issues/15))


geoops 0.1.2
============

### BUG FIXES

* Fixed bugs in C++ code that were causing build failures on some
systems (rdevel gcc Debian/Fedora and oldrel OSX)
* Updated C++ JSON library
* Add Niels Lohmann as cph


geoops 0.1.0
============

### NEW FEATURES

* Released to CRAN.
