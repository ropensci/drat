library(testthat)
library(sarsop)

test_check("sarsop")
