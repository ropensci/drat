#ifndef States_H
#define States_H

#include <string>
#include <map>
#include "SymbolSet.h"
#include "MObject.h"
#include "IVariableValue.h"
#include "IVariable.h"
#include "VariableContainer.h"

#define States VariableContainer
#define StateVal ValueSet 


#endif

