# Q-Q Plots

Example: <http://bl.ocks.org/4349187>
