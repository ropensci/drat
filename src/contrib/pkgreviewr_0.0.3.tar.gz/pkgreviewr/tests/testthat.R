library(testthat)
library(pkgreviewr)
library(magrittr)

test_check("pkgreviewr")
