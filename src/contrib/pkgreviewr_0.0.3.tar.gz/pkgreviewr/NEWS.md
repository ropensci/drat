# pkgreviewr 0.0.3

* Added a `NEWS.md` file to track changes to the package.
* Added package level documentation
* Combined `pkgreview_create()` and `pkgreview_init()`


# pkgreviewr 0.0.2

* Addressed initial installation bugs.
* Added checks for Rstudio and GitHub credentials


# pkgreviewr 0.0.1

* Initial prototype

