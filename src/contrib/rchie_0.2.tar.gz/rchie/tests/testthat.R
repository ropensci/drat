library(testthat)
library(rchie)

# if (identical(Sys.getenv("NOT_CRAN"), "true")) {
#   testthat::test_examples('../man')
# }

test_check("rchie")
