#' Species lists getter
#'
#' @importFrom spocc occ occ2df
#' @importFrom rgbif occ_search
#' @name spplist-package
#' @aliases spplist
#' @docType package
#' @keywords package
NULL
