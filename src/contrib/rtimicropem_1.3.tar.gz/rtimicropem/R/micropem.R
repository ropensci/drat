#' Supports the analyses of RTI MicroPEM output files.
#'
#' micropem allows you to read and analyse data from MicroPEM output files
#' in a reproducible way.
#'
"_PACKAGE"
# > [1] '_PACKAGE'
