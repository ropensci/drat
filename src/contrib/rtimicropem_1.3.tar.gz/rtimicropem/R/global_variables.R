globalVariables(c("datetime", "value"))
