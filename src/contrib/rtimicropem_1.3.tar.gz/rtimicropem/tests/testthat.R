library(testthat)
library(rtimicropem)

testthat::test_check("rtimicropem")
