# rtimicropem 1.3

* All functions now have snake_case names.

# rtimicropem 1.2

* Added a `NEWS.md` file to track changes to the package.



