#' @title Defunct
#' @description The following items are defunct in this release of dataone and are
#' no longer supported.
#' @name dataone-defunct
#' @keywords internal
#' @section These S4 methods are defunct:
#' \itemize{
#'  \item{\code{\link{setObsoletedBy}}}{: Set a pid as being obsoleted by another pid.}
#' }
NULL