library(testthat)
library(wicket)

test_check("wicket")
