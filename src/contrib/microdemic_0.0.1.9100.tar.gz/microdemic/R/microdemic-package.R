#' Microsoft Academic Client
#'
#' @name microdemic-package
#' @aliases microdemic
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
