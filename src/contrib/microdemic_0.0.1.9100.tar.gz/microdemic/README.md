microdemic
==========



[![Build Status](https://api.travis-ci.org/ropenscilabs/microdemic.png?branch=master)](https://travis-ci.org/ropenscilabs/microdemic)

`microdemic` - Microsoft Academic Client

## install


```r
devtools::install_github("ropenscilabs/microdemic")
```


```r
library("microdemic")
```

## Authentication

...

## Methods matching API routes

### Interpret

...

### Evaluate

...

### Calchistogram

...

## Higher level methods

### Search

...

## Meta

* Please [report any issues or bugs](https://github.com/ropenscilabs/microdemic/issues).
* License: MIT
* Get citation information for `microdemic` in R doing `citation(package = 'microdemic')`
* Please note that this project is released with a [Contributor Code of Conduct](CONDUCT.md). By participating in this project you agree to abide by its terms.
