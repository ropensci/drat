#' canpaginate
#'
#' Pagination Helper For Working With 'REST' 'APIs'
#'
#' @name canpaginate-package
#' @importFrom R6 R6Class
#' @importFrom tibble as_data_frame
#' @aliases canpaginate
#' @docType package
#' @keywords package
#' @author Scott Chamberlain \email{myrmecocystus+r@@gmail.com}
#'
#' @section Package API:
#' x
NULL
